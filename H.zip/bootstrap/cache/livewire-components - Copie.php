<?php return array (
  'clocking.clockings-details-correct-list' => 'App\\Http\\Livewire\\Clocking\\ClockingsDetailsCorrectList',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'crane.crane-list' => 'App\\Http\\Livewire\\Crane\\CraneList',
  'customer.customer-list' => 'App\\Http\\Livewire\\Customer\\CustomerList',
  'provider.provider-list' => 'App\\Http\\Livewire\\Provider\\ProviderList',
  'provider.provider-list-head' => 'App\\Http\\Livewire\\Provider\\ProviderListHead',
  'reassort.reassort-list-head' => 'App\\Http\\Livewire\\Reassort\\ReassortListHead',
  'reassort.reassort-list-parts' => 'App\\Http\\Livewire\\Reassort\\ReassortListParts',
  'reassort-level.reassort-level-list' => 'App\\Http\\Livewire\\ReassortLevel\\ReassortLevelList',
  'store.store-list' => 'App\\Http\\Livewire\\Store\\StoreList',
  'store.store-list-head' => 'App\\Http\\Livewire\\Store\\StoreListHead',
  'technician.technician-list' => 'App\\Http\\Livewire\\Technician\\TechnicianList',
  'worksheet.worksheet-list' => 'App\\Http\\Livewire\\Worksheet\\WorksheetList',
  'worksheet.worksheet-list-head' => 'App\\Http\\Livewire\\Worksheet\\WorksheetListHead',
  'report.partmetadata-export-data-table' => 'App\\Reports\\PartmetadataExportDataTable',
  'report.report-truckscrane-history'  => 'App\\Reports\\ReportTruckscraneHistory',
  'report.report-stock-reassortment'  => 'App\\Reports\\ReportStockReassortment',
  'report.report-worksheets-clockings'  => 'App\\Reports\\ReportWorksheetsClockings',
  'crane.crane-livewire' => 'App\\Http\\Controllers\\CraneLivewireController',
  'worksheet.worksheet-livewire' => 'App\\Http\\Controllers\\WorksheetLivewireController'

);
