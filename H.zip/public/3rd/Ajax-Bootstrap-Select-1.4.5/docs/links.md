[Bootstrap 3.2.0+]: http://getbootstrap.com/getting-started/#download
[Bootstrap prerequisite]: http://getbootstrap.com/getting-started/#whats-included
[Bootstrap]: http://getbootstrap.com

[Bootstrap Select 1.6.3+]: https://github.com/silviomoreto/bootstrap-select/releases/tag/v1.6.3
[Bootstrap Select]: https://github.com/silviomoreto/bootstrap-select

[jQuery 1.9+]: http://jquery.com/download/
[jQuery]: http://jquery.com
