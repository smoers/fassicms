Example can be run using Node v6+, run `yarn install` or `npm install` in example directory then `yarn start` or `npm start`.
