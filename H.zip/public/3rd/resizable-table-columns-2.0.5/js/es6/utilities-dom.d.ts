export declare class UtilitiesDOM {
    static getDataAttributesValues(el: HTMLElement): object | null;
}
