(function($) {
  Object.assign($.fn.checkboxpicker.defaults, {
    offLabel: 'No',
    onLabel: 'Si',
    warningMessage: 'Por favor, no utilice Bootstrap-checkbox para elementos tipo label.'
  });
})(jQuery);
