<?php return array (
  'brother' =>
  array (
    'description' => 'brother 62x29',
    'w' => 62,
    'h' => 29,
    'bcx' => 0,
    'bcy' => 12,
    'bcw' => 62,
    'bch' => 14,
    'pnx' => 0,
    'pny' => 7,
    'pnw' => 62,
    'pnh' => 6,
    'hex' => 3,
    'hey' => 3,
    'xres' => 0.2,
  ),
    'brother-GL-800' =>
    array(
        'description' => 'brother GL-800 90x38',
        'w' => 90,
        'h' => 38,
        'bcx' => 0,
        'bcy' => 12,
        'bcw' => 80,
        'bch' => 20,
        'pnx' => 15,
        'pny' => 7,
        'pnw' => 62,
        'pnh' => 6,
        'hex' => 3,
        'hey' => 3,
        'xres' => 0.8,
    )
);
