(function($) {
  Object.assign($.fn.checkboxpicker.defaults, {
    offLabel: 'Nie',
    onLabel: 'Tak',
    warningMessage: 'Nie używaj elementu Bootstrap-checkbox wewnątrz elementu label.'
  });
})(jQuery);
